package border;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class BorderDAO {

	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
		
	//		---------- DB���� ----------  //
	public BorderDAO() {
		try {
			String dbURL = "jdbc:mysql://localhost:3306/BBS_db";//mysql ��ġ
			String dbID = "root";//mysql ID
			String dbPassword = "root";//mysql PASSWORD
			Class.forName("com.mysql.cj.jdbc.Driver");//���� ����̹�
			conn=DriverManager.getConnection(dbURL, dbID, dbPassword);//DB�������� �� ����
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//���
	public ArrayList<Border> getList(){
		//String SQL = "SELECT * FROM bbs WHERE bbsID<? AND bbsAvailable = 1";
		String SQL = "SELECT * FROM Border ORDER BY ȸ����ȣ DESC";                        
		ArrayList<Border> list = new ArrayList<Border>();
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			//pstmt.setInt(1, getNext() - (pageNumber-1)*10);
			//pstmt.setInt(1, recordCount() - (recordCount()-(pageNumber-1)*10));
			rs=pstmt.executeQuery();
			while(rs.next()) {
				Border border = new Border();
				border.setMemberNum(rs.getInt(1));
				border.setTitle(rs.getString(2));
				border.setContent(rs.getString(3));
				list.add(border);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	//���� �б�
		public Border getBorder(int memberNum) {
			String SQL = "SELECT * FROM Border WHERE ȸ����ȣ = ?";
			try {
				PreparedStatement pstmt=conn.prepareStatement(SQL);
				pstmt.setInt(1,memberNum);
				rs=pstmt.executeQuery();
				if(rs.next()) {
					Border border = new Border();
					border.setMemberNum(rs.getInt(1));
					border.setTitle(rs.getString(2));
					border.setContent(rs.getString(3));
					return border;
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
			return null;
			
		}
	
	//������ �� ������ȣ ���ϱ�
	public int getNext() {
		String SQL = "SELECT ȸ����ȣ FROM Border ORDER BY bbsID DESC";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1) + 1;//������ȣ
			}else {
				return 1;//���۹�ȣ
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;//������ȣ
	}
	
	//������ �޼ҵ�
		public int write(Integer memberNum, String Title, String Content) {
			String SQL = "INSERT INTO Border VALUES(?,?,?)";
			try {
				PreparedStatement pstmt=conn.prepareStatement(SQL);
				pstmt.setInt(1, memberNum);
				pstmt.setString(2, Title);
				pstmt.setString(3, Content);
				return pstmt.executeUpdate();
			}catch (Exception e) {
				e.printStackTrace();
			}
			return -1;//�����ͺ��̽� ����
		}
	
	
	/*
	//������ �޼ҵ�
	public int write(String bbsTitle,String userID,String bbsContent) {
		String SQL = "INSERT INTO bbs VALUES(?,?,?,?,?,?)";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext());
			pstmt.setString(2, bbsTitle);
			pstmt.setString(3, userID);
			pstmt.setString(4, getDate());
			pstmt.setString(5, bbsContent);
			pstmt.setInt(6, 1);
			return pstmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;//�����ͺ��̽� ����
	}
	
	//���ڵ��� ����
	public int recordCount() {
		String SQL = "SELECT * FROM bbs WHERE bbsAvailable=1";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);				
			rs=pstmt.executeQuery();
			int recordCount = 1;
			while(rs.next()) {
				recordCount++;
			}
			return recordCount;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	
	
	
	//������ ó�� �޼���
	public boolean nextPage(int pageNumber) {
		//String SQL = "SELECT * FROM bbs WHERE bbsID<? AND bbsAvailable = 1";
		String SQL = "SELECT * FROM bbs WHERE bbsAvailable = 1 ORDER BY bbsID DESC LIMIT ?,10";
		
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			//pstmt.setInt(1, getNext() - (pageNumber-1)*10);
			pstmt.setInt(1, recordCount() - (recordCount()-(pageNumber-1)*10));
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return true;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	//������ ������ ��ȣ �޼���
		public int getPages() {
			String SQL = "SELECT * FROM bbs WHERE bbsAvailable=1";
			try {
				PreparedStatement pstmt=conn.prepareStatement(SQL);				
				rs=pstmt.executeQuery();
				int recordCount = 0;
				while(rs.next()) {
					recordCount++;
				}
				return (recordCount-1) / 10 + 1;
			}catch(Exception e) {
				e.printStackTrace();
			}
			return -1;
		}
	
	//���� �б�
	public Bbs getBbs(int bbsID) {
		String SQL = "SELECT * FROM bbs WHERE bbsID = ?";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setInt(1,bbsID);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				Bbs bbs = new Bbs();
				bbs.setBbsID(rs.getInt(1));
				bbs.setBbsTitle(rs.getString(2));
				bbs.setUserID(rs.getString(3));
				bbs.setBbsDate(rs.getString(4));
				bbs.setBbsContent(rs.getString(5));
				bbs.setBbsAvailable(rs.getInt(6));
				return bbs;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	
	//�ۼ��� �޼ҵ�
	public int update(String bbsTitle,String userID,String bbsContent,int bbsID) {
		String SQL = "UPDATE bbs SET bbsTitle=?,bbsContent=? WHERE userID=? AND bbsID=?";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setString(1, bbsTitle);
			pstmt.setString(2, bbsContent);
			pstmt.setString(3, userID);
			pstmt.setInt(4, bbsID);
			return pstmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;//�����ͺ��̽� ����
	}
	
	//����¥ ���� �޼ҵ�
	public int delete(String userID,int bbsID) {
		String SQL = "DELETE FROM bbs WHERE bbsID=? AND userID=?";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setInt(1, bbsID);
			pstmt.setString(2, userID);			
			return pstmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;//�����ͺ��̽� ����
	}
	
	//�۰�¥ ���� �޼ҵ�
	public int delete2(String userID,int bbsID) {
		String SQL = "UPDATE bbs SET bbsAvailable = 0 WHERE bbsID=? AND userID=?";
		try {
			
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setInt(1, bbsID);
			pstmt.setString(2, userID);			
			return pstmt.executeUpdate();			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;//�����ͺ��̽� ����
	}
	*/
	
	
}